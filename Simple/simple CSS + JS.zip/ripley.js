// Header New Manifest

// Link servicio a cliente bluemix -> estático
$(document).ready(() => {
	$('.footer__links-container a').eq(0).attr('href', 'http://simple.ripley.cl/minisitios/estatico/servicio_cliente/')
})
